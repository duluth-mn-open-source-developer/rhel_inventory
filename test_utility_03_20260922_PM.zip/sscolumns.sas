/*******************************************************************************
* Program Name: sscolumns.sas
* Program Type: Smartsheet Utility Macro
* Description : Reformat Smartsheet columns to better match SAS header metadata.
* Created By  : Wayne Saraphis
* Created     : Sep 01, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin         - Smartsheet columns input dataset (_out_.columns)
*  dsout        - Output dataset name 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 01, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro sscolumns(
  dsin=_out_.columns,
  dsout=columns
 )/des="Smartsheet: Reformat columns to better match SAS header metadata."
;
   data &dsout.;
      label 
         id        = "Smartsheet Column Id"
         _varnum   = "SAS Variable Number"
         _name     = "SAS Variable Name"
         _label    = "SAS Label"  
         _informat = "SAS Informat"  
         _format   = "SAS Format"  
      ;  
      set &dsin.;
      if title ne 'Primary Column';
      _varnum = ordinal_columns-1;
      _name = lowcase(tranwrd(trim(title),' ','_'));
      _label  = title;
      _informat=cats('$',input(left(width),$8.),'.');
      _format = _informat;
      if type = "DATETIME" then _format = "datetime20.";
      keep id _varnum _name _label _informat _format;
   run; 
%mend sscolumns;
%* sscolumns;
