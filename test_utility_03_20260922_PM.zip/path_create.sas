/*******************************************************************************
* Program / Macro : path_create.sas
* Purpose     : Recursively creates a full Windows directory path from a
*               macro string using the SAS DCREATE function.
* Created By  : Wayne Saraphis
* Created     : August 14, 2026
*
* Usage       : %create_path(path=C:\Projects\Clinical\Data\Raw);
*
* Inputs      : path - Target full directory path (Drive letter or UNC)
*
* Notes       : 1. Automatically converts forward slashes to backslashes.
*               2. Validates base root accessibility before proceeding.
*               3. Handles multi-level directory trees sequentially.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 20, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro path_create
 (
  path=
 )/des="Utility - Create empty folder structure from a full path."
;

    %local clean_path count start_idx i subfolder parent_path check_path status_rc;

    /* 1. Parameter Validation */
    %if %length(&path.) = 0 %then %do;
        %put ERROR: [CREATE_PATH] Parameter 'path' cannot be empty.;
        %return;
    %end;

    /* 2. Normalize input string (remove quotes, unify slashes) */
    %let clean_path = %sysfunc(dequote(&path.));
    %let clean_path = %sysfunc(translate(&clean_path., \, /));

    /* Strip trailing backslash if present */
    %if %sysfunc(substr(&clean_path, %length(&clean_path.), 1)) = \ %then %do;
        %let clean_path = %substr(&clean_path, 1, %eval(%length(&clean_path.) - 1));
    %end;

    %if %length(&clean_path.) < 3 %then %do;
        %put ERROR: [CREATE_PATH] Invalid or incomplete path specification: &clean_path.;
        %return;
    %end;

    /* 3. Determine Root Path Type (UNC Path vs. Drive Letter) */
    %let count = %sysfunc(countw(&clean_path., \));

    %if %substr(&clean_path, 1, 2) = %str(\\) %then %do;
        /* UNC Path Format: \\server\share */
        %let parent_path = \\%sysfunc(scan(&clean_path., 1, \))\%sysfunc(scan(&clean_path., 2, \));
        %let start_idx = 3;
    %end;
    %else %if %sysfunc(indexc(&clean_path., :)) > 0 %then %do;
        /* Standard Drive Letter Format: C:\ */
        %let parent_path = %sysfunc(scan(&clean_path., 1, \))\;
        %let start_idx = 2;
    %end;
    %else %do;
        %put ERROR: [CREATE_PATH] Path must include a drive letter (e.g. C:\) or UNC prefix (\\): &clean_path.;
        %return;
    %end;

    /* 4. Validate Base Root Existence */
    %if %sysfunc(fileexist(&parent_path.)) = 0 %then %do;
        %put ERROR: [CREATE_PATH] Base root directory does not exist or is inaccessible: &parent_path.;
        %return;
    %end;

    /* 5. Recursive Directory Traversal & Creation */
    %do i = &start_idx %to &count.;
        %let subfolder = %sysfunc(scan(&clean_path., &i, \));
       
        /* Construct target check path without double slashes */
        %if %sysfunc(substr(&parent_path, %length(&parent_path.), 1)) = \ %then %do;
            %let check_path = &parent_path.&subfolder.;
        %end;
        %else %do;
            %let check_path = &parent_path.\&subfolder.;
        %end;

        /* Check level existence; invoke DCREATE if missing */
        %if %sysfunc(fileexist(&check_path.)) = 0 %then %do;
            %let status_rc = %sysfunc(dcreate(&subfolder., &parent_path.));
           
            %if %length(&status_rc.) = 0 %then %do;
                %put ERROR: [CREATE_PATH] DCREATE failed at path level: &check_path.;
                %return;
            %end;
            %else %do;
                %put NOTE: [CREATE_PATH] Directory successfully created: &check_path.;
            %end;
        %end;

        /* Advance parent pointer to current depth */
        %let parent_path = &check_path;
    %end;

    %put NOTE: [CREATE_PATH] Target path verified/ready: &parent_path.;
%mend path_create;

