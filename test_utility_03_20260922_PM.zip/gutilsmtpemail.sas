/*******************************************************************************
* Program Name: gutilsmtpemail.sas
* Program Type: Global Utility Macro
* Purpose     : Generic utility macro for sending automated email alerts and  
*               reports via SMTP using SAS email capabilities. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  smtp_host              - Mail host
*  smtp_port              - Mail host port (25)
*  sender_email           - Sender email
*  recipient_email        - Recipient email
*  email_subject          - Email subject
*  message_body_path      - Email message
*  attachment_path        - Include attachment
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gutilsmtpemail
 (
  smtp_host=,
  smtp_port=25,
  sender_email=,
  recipient_email=,
  email_subject=,
  message_body_path=,
  attachment_path=
 )/des="Global: Utility macro to send emails."
;

    /* ----------------------------------------------------------------- */
    /* Set SMTP options for the SAS session                              */
    /* ----------------------------------------------------------------- */
    options 
        emailhost  = "&smtp_host."
        emailport  = &smtp_port.
        emailsid   = "&sender_email."
    ;

    %put NOTE: Configuring SMTP connection to &smtp_host.:&smtp_port.;

    /* ----------------------------------------------------------------- */
    /* Define email attachment fileref if provided                       */
    /* ----------------------------------------------------------------- */
    %local attach_opt;
    %if %length(&attachment_path.) > 0 %then %do;
        %if %sysfunc(fileexist(&attachment_path.)) = 0 %then %do;
            %put WARNING: Attachment file path does not exist: &attachment_path.;
        %end;
        %else %do;
            filename attach "&attachment_path.";
            %let attach_opt = attach=attach;
            %put NOTE: Email attachment included: &attachment_path.;
        %end;
    %end;

    /* ----------------------------------------------------------------- */
    /* Open email output fileref and write message                       */
    /* ----------------------------------------------------------------- */
    filename mail email
        to=("&recipient_email.")
        subject="&email_subject."
        &attach_opt.
    ;

    data _null_;
        file mail;
        /* If a body file path is provided, read and write its contents */
        %if %length(&message_body_path.) > 0 %then %do;
            %if %sysfunc(fileexist(&message_body_path.)) > 0 %then %do;
                infile "&message_body_path." truncover;
                input;
                put _infile_;
            %end;
            %else %do;
                put "WARNING: Message body file not found. Sending default notification text.";
                put "Automated notification from Iambic Pharma SAS analytics pipeline.";
            %end;
        %end;
        %else %do;
            put "Automated notification from Iambic Pharma SAS analytics pipeline.";
            put "Process execution completed successfully.";
        %end;
    run;

    %put NOTE: SMTP email successfully transmitted to &recipient_email.;

    /* ----------------------------------------------------------------- */
    /* Clean up filerefs                                                 */
    /* ----------------------------------------------------------------- */
    filename mail clear;
    %if %length(&attachment_path.) > 0 and %sysfunc(fileexist(&attachment_path.)) > 0 %then %do;
        filename attach clear;
    %end;

%mend gutilsmtpemail;