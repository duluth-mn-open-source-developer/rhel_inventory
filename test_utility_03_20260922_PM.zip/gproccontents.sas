/*******************************************************************************
* Program Name: gproccontents.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC CONTENTS with optional
*               metadsin dsoutput dsinset and detail-level control.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical dsin pipeline architectures
*               requiring secure communication with external Electronic dsin
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log dsoutput and controlled error
*               handling withdsout breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin              - Input dsin.
*  dsout             - dsoutput dsin.
*  details           - Details (Yes) 
*  noprint           - No print (NO)
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gproccontents(
    dsin=,
    dsout=,
    details=,
    noprint=
  )/des="Global: Utility macro for PROC CONTENTS."
;
    %local m_err;
    %let m_err = 0;

    /* Parameter validation */
    %if %length(&dsin.) = 0 %then %do;
        %put ERROR: [utl_contents] Input dsinset (dsin=) must be specified.;
        %let m_err = 1;
    %end;

    %if &m_err. = 1 %then %goto exit;

    /* Execution */
    proc contents data=&dsin.
        %if %length(&dsout.) > 0 %then out=&dsout.(label=Contents for &dsin.);
        %if %upcase(&details.) = NO %then nodetails;;
        %if %upcase(&noprint.) = YES %then noprint;;
        ;
    run;
    
    proc sort data=&dsout.; by varnum; run;

    %put NOTE: [gcontents] Successfully processed contents for &dsin.;

%exit:
%mend gproccontents;
%* gproccontents(dsin=joinedwide,dsout=cjoinedwide);
