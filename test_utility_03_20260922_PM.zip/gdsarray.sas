/*******************************************************************************
* Program Name: gdsarray.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro to create a macro array. 
* Created By  : Wayne Saraphis
* Created     : August 14, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin              - (Mandatory) Input SAS dataset.
*  var               - (Mandatory) Variable with value to put into the array.
*  counter           - (Optional) Counter for macro array.
*                      Default: total
*  prefix            - Prefix for the array Default: name
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 14, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdsarray
 (
  dsin    =,
  var     =,
  counter = total,
  prefix  = name
 )/des="Global: Utility macro to create a macro array."
;
   
    /* 1. Use a data step with CALL SYMPUTX to push each value globally */
    data _null_;
        set &dsin.(where=(compress(&var.) <> "" ));
        call symputx(cats("&prefix.",_n_), &var.,'G');
        call symputx("&counter.",_n_,'G');
    run;

    /* 3. Logging the var name and value details */
    %put NOTE: Created global array "&prefix." with &&&counter. elements from dataset &dsin.;
    %put NOTE: Source var parsed: &var.;
    %put NOTE: Count has the value &&&counter.;
    %do ii = 1 %to &&&counter.;
        %put NOTE: the global macro var &prefix&ii. has the value &&&prefix&ii..;
    %end;

%mend gdsarray;
%* gdsarray
 (
  dsin   = sashelp.cars,
  var    = model,
  prefix = model
 )
;
