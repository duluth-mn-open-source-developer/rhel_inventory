/*******************************************************************************
* Program Name : gfiletemplate.sas
* Program Type : Global Utility Macro
* Description  : Generic utility macro to populate a project template. 
* Created By   : Wayne Saraphis
* Created      : August 25, 2026
*
* Parameters:
*  pathout     - Path to new project configuration.
*  pathin      - Path to template.
*  compound    - Applies to a new compound.
*  study       - Applies to a new study.
*  year        - Applies to a new year.
*  project     - Applies to a new project.
*  vendor      - Applies to a new vendor.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 25, 2026  | Wayne Saraphis | Create program.
* 0.2     | Aug 26, 2026  | Wayne Saraphis | Modify code logic.
*******************************************************************************/
%macro gfiletemplate(
  pathout=,
  pathin=,
  compound=,
  study=,
  year=,
  project=,
  vendor=
 )
;
   data _null_;
      infile "&pathin." truncover dsd lrecl=500 pad;
      file "&pathout." dsd pad;
      length raw_line $500.;
      input raw_line $ 1-500;
      raw_line=tranwrd(strip(raw_line),"<Compound>","&compound.");
      raw_line=tranwrd(strip(raw_line),"<Study>","&study.");
      raw_line=tranwrd(strip(raw_line),"<Year>","&year.");
      raw_line=tranwrd(strip(raw_line),"<Project>","&project.");
      raw_line=tranwrd(strip(raw_line),"<Vendor>","&vendor.");
      put raw_line;
   run; 
%mend gfiletemplate;
%* gftemplate(
  pathin=D:/DM and Programming/DM/Utilities/data/project_folders_short.txt,
  pathout=D:/DM and Programming/DM/Utilities/data/combine_rtf.txt,
  project=combine_rtf
 ) 
; 
