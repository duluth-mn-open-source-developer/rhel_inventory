/*******************************************************************************
* Program Name: gmvarparsedsn.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for parsing library dataset names into two
                global macro variables one for the library and one for datset name. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsn          - Input library and dataset name.
*  mlib         - Global macro name for the library value (out_lib).
*  mdsn         - Global macro name for the dataset name value (out_dsn).
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gmvarparsedsn(
  dsn=,
  mlib=out_lib,
  mdsn=out_dsn
 )/des="Global: Parsing library dataset names into two global macro variables"
;
   
   %global &mlib. &mdsn.;
    
   %if %index(&dsn., .) %then %do;
      %let &mlib. = %scan(&dsn., 1, .);
      %let &mdsn.  = %scan(&dsn., 2, .);
   %end;
      %else %do;
         %let &mlib. = WORK;
         %let &mdsn. = &dsn.;
      %end;
    
   %put NOTE: the global macro variable &mlib. has the value &&&mlib.;
   %put NOTE: the global macro variable &mdsn has the value &&&mdsn;
   
%mend gmvarparsedsn;