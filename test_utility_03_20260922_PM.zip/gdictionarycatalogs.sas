/*******************************************************************************
* Program Name: gdictionarycatalogs.sas
* Program Type: Global Utility Macro
* Description : Generic utility macros for getting macro information.       
* Created By  : Wayne Saraphis
* Created     : August 25, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsout                  - Output dataset.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 25, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdictionarycatalogs
 (
  dsout=work.catalog,
 )/des="Global: Utility macro to get a list of all macros."
;

   proc sql noprint;
      create table &dsout. as 
      select * 
      from dictionary.catalogs;
   quit;
 
   
%mend gdictionarycatalogs;

