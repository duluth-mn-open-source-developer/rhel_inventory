/*******************************************************************************
* Program Name: gprocsort.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC SORT with optional
*               duplicate removal and dedicated duplicate output.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  data                   - Input datasets
*  out                    - Output datasets
*  by                     - Sort variables
*  nodupkey               - Remove duplicate records (NO)
*  dups                   - Allow duplicates
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocsort(
    data=,
    out=,
    by=,
    nodupkey=N,
    dups=
 )/des="Global: Utility macro for PROC SORT."
;
    %local m_err;
    %let m_err = 0;

    /* Parameter validation */
    %if %length(&data.) = 0 %then %do;
        %put ERROR: [gsort] Input dataset (data=) must be specified.;
        %let m_err = 1;
    %end;
   
    %if %length(&by.) = 0 %then %do;
        %put ERROR: [gsort] BY variables (by=) must be specified.;
        %let m_err = 1;
    %end;

    %if &m_err. = 1 %then %goto exit;

    /* Default output to input dataset name if out= is omitted */
    %if %length(&out.) = 0 %then %let out = &data.;

    /* Execution */
    proc sort data=&data.
        %if %upcase(&nodupkey.) = Y %then nodupkey;;
        %if %length(&out.) > 0 %then out=&out.
        %if %length(&dups.) > 0 %then dupout=&dups.;
        ;
        by &by.;
    run;

    %put NOTE: [gsort] Successfully processed sorting for &data. -> &out.;

%exit:
%mend gprocsort;
