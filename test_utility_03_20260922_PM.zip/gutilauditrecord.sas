/*******************************************************************************
* Program Name: gutilauditrecord.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for creating an audit record. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters   
*  list_num     - List number 
*  list_title   - List title
*  status       - Status
*  record_count - Record count
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gutilauditrecord
 (
  list_num=, 
  list_title=, 
  dsout=work.temp_log_row,
  status=, 
  record_count=
 )/des="Global: Utility macro for creating an audit record."
;
    data &dsout.;
        length id $10. title $50. status $10. records 8. timestamp $20.;
        id = "&list_num.";
        title      = "&list_title.";
        status     = "&status.";
        records    = &record_count.;
        timestamp  = "%sysfunc(datetime(), datetime20.)";
        output;
    run;

    proc append base=work.execution_log data=work.temp_log_row force;
    run;

    proc delete data=work.temp_log_row;
    run;
    
%mend gutilauditrecord;
