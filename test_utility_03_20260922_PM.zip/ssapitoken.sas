/*******************************************************************************
* Program Name : ssapitoken.sas
* Program Type : Smartsheet Macro
* Description  : Sets global macro variable for the Smartsheet bearer token. 
* Created By   : Wayne Saraphis
* Created      : August 30, 2026
*
* Parameters:
*  pathin       - Path for bearer token file.
*  filein       - File with bearer token.
*  mvar         - Global macro variable with bearer token value.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 30, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssapitoken(
  pathin=D:/DM and Programming/DM/Utilities/00-setup/api-tokens,
  filein=smartsheet.txt,
  mvar=api_token
 )/des="Smartsheet: Sets global macro variable for the Smartsheet bearer token"
; 

   data _null_;
      infile "&pathin./&filein." truncover;
      length string $512.;
      input string $;
      call symputx("&mvar.",strip(string),'G');
   run; 

   %put NOTE: the global macro variable &mvar. has the value &&&mvar.;
   
%mend ssapitoken;
