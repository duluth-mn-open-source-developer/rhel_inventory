/*******************************************************************************
* Program Name : glowcasestring.sas
* Program Type : Global Utility Macro
* Description  : Generic utility macro lowcase a string to a the log. 
* Created By   : Wayne Saraphis
* Created      : September 04, 2026
*
* Parameters:
*  string      - String to lowcase.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 04, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro glowcasestring(string=)/des="Global: Lowcase a string.";
   data _null_;
      format string $100.;
      string=lowcase("&string.");
      put @7 string;
   run;
%mend glowcasestring;   
