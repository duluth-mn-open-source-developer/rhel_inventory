/*******************************************************************************
* Program Name: gprochttp.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for executing REST API calls using
*               PROC HTTP, featuring automated JSON library mapping for GET
*               requests, bearer token authentication, robust method support,
*               status capture variables, and safe error-trapping cleanup.
* Created By  : Wayne Saraphis
* Created     : August 14, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  url               - (Mandatory) The fully qualified REST endpoint URI.
*  method            - (Mandatory) HTTP verb to execute. 
                       Valid values: GET, POST, PUT, DELETE, HEAD. 
                       Default: GET.
*  bearer_token      - (Mandatory) OAuth / API token string injected into the
                       Authorization request header. 
                       Default: blank.
*  content_type      - (Mandatory) Request media type header value.
                       Default: application/json.
*  timeout_seconds   - (Mandatory) Connection timeout threshold in seconds.
                       Default: 60.
*  libout            - Library out default: _out_
   libpath           - Library path
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 14, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprochttp
 (
  url=,
  method=GET,
  bearer_token=,
  json_in=,
  json_out=_resp_,
  content_type=application/json,
  timeout_seconds=60,
  libout=_out_,
  libpath=
 )/des="Global: Utility macro to GET, POST, PUT, and DELETE HTTP API calls."
;

   * Define input/output filerefs;
   filename &json_out. temp;

   * Execute PROC HTTP;
   proc http
      url="&url."
      method="&method."
      %if %lowcase(&method.)=post %then %do;
         in=&json_in.
      %end;
      %if %lowcase(&method.)=get %then %do;
         out=&json_out.
      %end;
      timeout=&timeout_seconds.
   ;
      headers "Authorization" = "Bearer &bearer_token." "Accept"="&content_type.";
   run;
   
   * Library for output to UTF-8 encoding;
   libname &libout. "&libpath." inencoding="UTF-8" outencoding="UTF-8" compress=YES;

   * Assign JSON library;
   libname _json_ json fileref=&json_out.;

   * Copy JSON to SAS datasets;
   proc copy in=_json_ out=&libout.; run;

   * Clear JSON filename;
   filename &json_out clear;

%mend gprochttp;