/*******************************************************************************
* Program Name: gprocdatasetsdelete.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro to safely delete datasets.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  data         - Dataset to delete.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocdatasetsdelete(
  data=
 )/des="Global: Utility macro to delete datasets."
;
    %if %length(&data.) = 0 %then %do;
        %put ERROR: [gdelete] Dataset (data=) must be specified.;
        %return;
    %end;

    %if %sysfunc(exist(&data.)) %then %do;
        proc datasets lib=%scan(&data., 1, .) nolist;
            delete %scan(&data., 2, .);
        quit;
        %put NOTE: [gdelete] Dataset &data. successfully deleted.;
    %end;
    %else %do;
        %put NOTE: [gdelete] Dataset &data. does not exist. Deletion skipped.;
    %end;
    
%mend gprocdatasetsdelete;

