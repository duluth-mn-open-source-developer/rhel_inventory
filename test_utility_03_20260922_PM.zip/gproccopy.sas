/*******************************************************************************
* Program Name  : gproccopy.sas
* Program Type  : Global Utility Macro
* Description   : Utility macro to copy SAS datasets or entire libraries using
*                 PROC COPY with built-in error handling and status logging.
* Created By    : Wayne Saraphis
* Created       : September 21, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  inlib        : Input library or dataset path. [Required]
*  outlib       : Output library or dataset path. [Required]
*  select       : Space-separated list of specific dataset names to copy
*                 (if copying at the library level). Leave blank to copy all. [Optional]
*  exclude      : Space-separated list of dataset names to exclude from copying. [Optional]
*  outstat      : Macro variable name to store the return status 
*                 (0 = Success, 1 = Error). [Optional]
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 21, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gproccopy(
  inlib =,
  outlib =,
  select =,
  exclude =,
  outstat =
 )/des="Global: Utility macro for PROC COPY."
;

   %local syserr_val copy_status;

   /* Parameter validation */
   %if %length(&inlib.) = 0 or %length(&outlib.) = 0 %then %do;
      %put %str(EE)ROR: [gproccopy] Both inlib and outlib parameters must be specified.;
      %if %length(&outstat.) > 0 %then %let &outstat. = 1;
      %goto exit;
   %end;

   %put %str(IN)FO: [gproccopy] Initiating copy operation from &inlib. to &outlib..;

   /* Execute PROC COPY */
   proc copy in=&inlib. out=&outlib.;
      %if %length(&select.) > 0 %then %do; select &select.; %end;
      %if %length(&exclude.) > 0 %then %do; exclude &exclude.; %end;
   ;
   run;

   /* Capture return code */
   %let syserr_val = &syserr.;

   %if &syserr_val. = 0 %then %do;
      %put %str(IN)FO: [gproccopy] Copy operation completed successfully.;
      %let copy_status = 0;
   %end;
      %else %do;
         %put %str(EE)ROR: [gproccopy] Copy operation failed with SYSERR = &syserr_val..;
         %let copy_status = 1;
      %end;

   /* Assign output status macro variable if requested */
   %if %length(&outstat.) > 0 %then %do;
      %let &outstat. = &copy_status.;
   %end;

   %exit:
%mend gproccopy;