/*******************************************************************************
* Program Name : ssgetids.sas
* Program Type : Smartsheet Utility Macro
* Purpose      : Smartsheet macro array with a list of Smartsheet Ids. 
* Created By   : Wayne Saraphis
* Created      : August 31, 2026
*
* Parameters:
*  dsnin        - Create global macro array with a list of Smartsheet Ids.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 31, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssgetids(
  dsin=
 )/des="Smartsheet: Get Ids from a sheet"
;
   data _null_;
      set &dsin.;
      xid = put(id,20.);
      call symputx(cat('id',_n_),strip(xid),'G');
      call symputx(cat('name',_n_),strip(name),'G');
      call symputx(cat('permalink',_n_),strip(permalink),'G');
      call symputx('totalids',_n_,'G');
   run;   
   %do jj = 1 %to &totalids.;
      %put NOTE: the global macro variable id&jj. has the value &&id&jj;
      %put NOTE: the global macro variable name&jj. has the value &&name&jj;
      %put NOTE: the global macro variable permalink&jj. has the value &&permalink&jj;
   %end;
%mend ssgetids;
/*
option mprint;
%ssgetids(dsin=_out_.data);
*/