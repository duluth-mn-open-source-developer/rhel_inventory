/*******************************************************************************
* Program Name : gfilearray.sas
* Program Type : Global Utility Macro
* Description  : Generic utility macro to create a macro array from a file. 
* Created By   : Wayne Saraphis
* Created      : August 25, 2026
*
* Parameters:
*  path         - (Mandatory) Input path and file.
*  delimiter    - (Optional) File column delimiter.
*                  Default: ~
*  dsout        - (Mandatory) Dataset out.
*  total        - Total variables in the macro array.
*  default      - Default macro variable prefix.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 25, 2026  | Wayne Saraphis | Create program.
* 0.2     | Aug 26, 2026  | Wayne Saraphis | Modify code logic.
*******************************************************************************/
%macro gfilearray
 (
  path        =,
  delimiter   =%str(~),
  dsout       =gfarray,
  total       =totalvars,
  default     =var
 )/des="Global: Parse name and value or just values from a file."
;

   data &dsout.;
      infile "&path." truncover dsd lrecl=500 pad;
      length record_num 8. name $32. record_num 8. raw_line parm value $500.;
       
      input raw_line $ 1-500;
      record_num + 1;
      raw_line = strip(raw_line);

      if index(raw_line,"&delimiter.") > 0 then do;
         name = compress("&default." || record_num);
         parm  = strip(scan(raw_line,1,"&delimiter.")); 
         if index(parm,'.')>0 then parm = tranwrd(lowcase(parm),'.','_');
         value  = strip(scan(raw_line,2,"&delimiter."));      
      end;
      if index(raw_line,"&delimiter.") = 0 then do;
         name = compress("&default." || record_num);
         parm  = name; 
         value  = strip(scan(raw_line, 1, "&delimiter."));      
      end;
      
      call symputx(name,value,'G');
      call symputx(cats('list',record_num),parm,'G');
      call symputx(parm,value,'G');
      call symputx("_temp_",record_num,'L');
      call symputx("&total.",record_num,'G');
       
      drop raw_line record_num;
      
      retain record_num 0;
   run;
   
   %do ii = 1 %to &_temp_.;
      %put NOTE: the macro variable var&ii. has the value &&var&ii..;
   %end;
   
   %put ;
   
   %do ii = 1 %to &_temp_.;
      %put NOTE: the macro variable list&ii. has the value &&list&ii.;
      * Remove list macro variable created to display the name and value;
      %symdel list&ii. /nowarn;
   %end; 

%mend gfilearray;
%* gfilearray
 (
  path        =%str(D:\DM and Programming\DM\Utilities\data\project_folders_short.txt),
  dsout       =gfarrray,
  total       =total,
  default     =var
 )
;

%* gfilearray
 (
  path        =%str(D:/DM and Programming/DM/Utilities/data/test_delimited.txt),
  dsout       =gfarrray,
  total       =total,
  default     =var
 )
;

