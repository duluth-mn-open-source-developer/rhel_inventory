/*******************************************************************************
* Program Name: gutiloptions.sas
* Program Type: Global Utility Macro
* Description : Set options for SAS execution.
*               This macro sets up the ODS RTF environment options, orientation, 
*               and layout styles universally required for clinical research reporting.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  validrun          - Options required for production execution (Y).
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gutiloptions
 (
  validrun=Y
 )/des="Global: Utility macro to set options for SAS execution."
;

    /* Ensure clear text/log output tracking */
    %if %sysfunc(kupcase(&validrun.)) = Y %then %do;
       options mprint mlogic symbolgen;
    %end;   
    %if %sysfunc(kupcase(&validrun.)) = N %then %do;
        options nomprint nomlogic nosymbolgen;
    %end;
    
    /* Enforce strict clinical output settings */
    options nodate nonumber missing=' ';
    ods escapechar='^';

%mend gutiloptions;
%* gutiloptions(validrun=N);
