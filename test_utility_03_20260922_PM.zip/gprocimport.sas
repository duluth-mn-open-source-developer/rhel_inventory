/*******************************************************************************
* Program Name: gprocimport.sas
* Program Type: Global Utility Macro
* Description : Generic utility PROC IMPORT SAS macros. 
* Created By  : Wayne Saraphis
* Created     : September 16, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsout             - (Mandatory) Output SAS dataset.
*  pathin            - (Mandatory) Input path.
*  dbms              - (Optional) Type of input (CSV).
*  getnames          - (Optional) Get variable names.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 16, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocimport(
  dsout=,
  pathin=,
  dbms=csv,
  getnames=yes
 )/des="Global: Generic PROC IMPORT macro"
;

   %web_drop_table(&dsout.);

   filename reffile "&pathin.";

   proc import datafile=reffile
	  dbms=&dbms.
	  out=&dsout.
      replace;
	  getnames=&getnames.;
	  guessingrows=max;
   run;
   
   data &dsout.;
      length count 3.;
      set &dsout.;
      count = _n_;
   run;

   proc contents data=&dsout.; run;

   %web_open_table(&dsout.);

%mend gprocimport;   