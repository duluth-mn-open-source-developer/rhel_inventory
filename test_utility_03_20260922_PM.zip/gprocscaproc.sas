/*******************************************************************************
* Program Name: gprocscaproc.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro leveraging PROC SCAPROC (SAS Code Analyzer)  
*               to capture data dependencies and runtime metadata. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  target_program_path          - Job path.
*  output_analysis_report_path  - Output path.
*  grid_enabled_flag            - Grid enabled path (N).
*  record                       - Record the inputs and outputs (Y).
*  write                        - Write to file path.  
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
* 0.2     | Aug 24, 2026  | Wayne Saraphis | Add options and macro logic for:
                                           | record, write, and expandmacro  
*******************************************************************************/
%macro  gprocscaproc
 (
   target_program_path=,
   output_analysis_report_path=,
   grid_enabled_flag=N
   record=Y
   write=
 )/des="Global: Macro for PROC SCAPROC."
;

    /* ----------------------------------------------------------------- */
    /* Validate target program existence                                 */
    /* ----------------------------------------------------------------- */
    %if %sysfunc(fileexist(&target_program_path.)) = 0 %then %do;
        %put ERROR: Target program path does not exist: &target_program_path.;
        %return;
    %end;

    %put NOTE: Initializing SAS Code Analyzer (PROC SCAPROC) for: &target_program_path.;

    /* ----------------------------------------------------------------- */
    /* Execute PROC SCAPROC to record lineage, dependencies, and I/O     */
    /* ----------------------------------------------------------------- */
    proc scaproc;
        %if &record. = Y %then %do;
            record "&output_analysis_report_path." expandmacros opentimes;
        %end;

        %if &write. = Y %then %do;
            write;
        %end;
        
        %if &grid_enabled_flag. = Y %then %do;
            grid;
        %end;
    run;

    %put NOTE: SAS Code Analyzer report successfully written to: &output_analysis_report_path.;

%mend  gprocscaproc;