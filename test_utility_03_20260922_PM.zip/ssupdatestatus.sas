/*******************************************************************************
* Program Name: ssupdatestatus.sas
* Program Type: Smartsheet Utility Macro
* Description : Update status column.
* Created By  : Wayne Saraphis
* Created     : Sep 02, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  rowid        -  Smartsheet row id
*  colummid     -  Smartsheet status column id
*  newstatus    -  New status value
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 02, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%include "D:/DM and Programming/DM/Utilities/02-macros/gprochttp.sas";
%macro ssupdatestatus(
    rowid=,
    columnid=,
    newstatus=
  )/des="Smartsheet: Update status column."
;

   filename json_out temp encoding="utf-8";
   * Create the JSON Request Body using DATA _NULL_;
   data _null_;
      file json_out encoding="utf-8";
      * Format the payload to update rows containing specific cells;
      put @1 '[';
      put @4 '{';
      put @7 '"id":' "&rowid." ',';
      put @7 '"cells": [';
      put @10 '{';
      put @13 '"columnId":' "&columnid." ',';
      put @13 '"value":' '"' "&newstatus." '"';
      put @10 '}';
      put @7 ']';
      put @4 '}';
      put @1 ']';
   run;

   data _null_;
      infile json_out truncover;
      length string $1024.;
      input string $;
      put string;
   run;

%mend ssupdatestatus;
* Update manually until UTF-8 is supported end-to-end.;
%* ssupdatestatus(
    rowid=5508757001469828,
    columnid=2332064365711236,
    newstatus=Completed
  )
;


%* gprochttp
 (
  url = &ssendpoint.,
  method = PUT,
  json_in=json_out,
  bearer_token = &api_token.,
  libout=_out_,
  libpath=&pathprocessid.
 )
;



