/*******************************************************************************
* Program Name: gmvarcurrentdt.sas
* Program Type: Global Utility Macro
* Purpose     : Create a global macro variable for date, time, or datetime.
* Created By  : Wayne Saraphis
* Created     : August 25, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  fmt         - Output format (YYMMDD10.)
*  mvar        - Global macro variable. (sys_date)
*  function    - the external date, time, or datetime values. (today())
*
* Current Date and Time Functions:
* today() Returns the current date as a SAS date value.
*  (number of days since January 1, 1960).
* date() Returns the current date as a SAS date value.
*  (number of days since January 1, 1960).
* time() returns the current time of day as a SAS time value.
*   (number of seconds since midnight).
* datetime() returns both the current date and time as a SAS datetime value. 
*  (number of seconds since January 1, 1960).
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 25, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gmvarcurrentdt(
    fmt   = YYMMDD10.,
    mvar = sys_date,
    function=today()
 )/des="Global: Utility macro to create global macro variable for date, time, or datetime."
;
    %global &mvar.;
    %let &mvar. = %sysfunc(putn(%sysfunc(&function.), &fmt.));
    %put NOTE: [gcurrentdt] Assigned the global &mvar. has the value &&&mvar..;
%mend gmvarcurrentdt;
/*
%gmvarcurrentdt(fmt=YYMMDD10.,mvar=sys_date,function=today());
%gmvarcurrentdt(fmt=MMDDYY10.,mvar=sys_date,function=date());
%gmvarcurrentdt(fmt=time5.,mvar=sys_time,function=time());
%gmvarcurrentdt(fmt=datetime20.,mvar=sys_date,function=datetime());
*/
