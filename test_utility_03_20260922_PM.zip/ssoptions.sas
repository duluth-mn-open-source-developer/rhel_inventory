/*******************************************************************************
* Program Name: ssoptions.sas
* Program Type: Smartsheet Utility Macro
* Description : Set options for Smartsheet execution.
* Created By  : Wayne Saraphis
* Created     : August 30, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  pathtemp     - Sets the temporary path for Smartsheet output.
*  mvar         - Date stamp for temporary folder (gmvaryyyymmdd_hhmmss).
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 30, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssoptions(
   pathtemp=,
   mvar=&gmvaryyyymmdd_hhmmss.
  )/des="Smartsheet: Create a temporary folder."
 ;
   %global pathprocessid;
   option dlcreatedir;
   %let pathprocessid=&pathtemp./_&sysprocessid._&mvar.;
   %put NOTE: the global macro variable pathprocessid has the value &pathprocessid.;
%mend ssoptions;
