%macro folders_delete(dir_path);
    /* Remove trailing slash if present */
    %let dir_path = %sysfunc(strip(&dir_path.));
    
    /* Check if directory exists before trying to delete */
    %if %sysfunc(fileexist(&dir_path.)) %then %do;
        /* Execute Windows rmdir command: /S removes tree, /Q is quiet mode */
        data _null_;
            call execute('x "rmdir /S /Q "' || "&dir_path." || '"";');
        run;
        %put NOTE: Folder &dir_path. and its contents have been deleted.;
    %end;
    %else %do;
        %put WARNING: Folder &dir_path. does not exist.;
    %end;
%mexit:
%mend folders_delete;

/* Example usage: */
%* folders_delete(D:\DM and Programming\DM\Utilities\96-scratch-data\_41DF5970C122B0214018000000000000_20260831_203339);
