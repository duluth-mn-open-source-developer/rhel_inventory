/*******************************************************************************
* Program Name: sysgetenvvars.sas
* Program Type: Global Utility Macro
* Description : Get system variables into log or dataset. 
* Created By  : Wayne Saraphis
* Created     : August 14, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  mode         - (Mandatory) Output location LOG or SAS dataset.
                  Default:  BOTH (LOG and SAS dataset)
*  dsout        - (Optional) Output dataset (work.env_variables)                    
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 14, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro sysgetenvvars
 (
  mode=BOTH, 
  dsout=work.env_variables
 )/des="System: Get environment variables."
;

   /* 1. Standardize input parameters to uppercase */
   %let mode = %upcase(&mode.);
   
   /* 2. Auto-detect Operating System command */
   %let os_cmd = ;
   %if %sysprod(sysscp) = 1 or %index(&sysscp., WIN) > 0 %then %do;
      %let os_cmd = set;
   %end;
   %else %do;
      %let os_cmd = env;
   %end;

   /* 3. Execute logic based on the requested MODE */
   %if &mode. = LOG %then %do;
      /* Process everything in the log without creating a dataset */
      filename envcmd pipe "&os_cmd." lrecl=32767;
      
      data _null_;
         infile envcmd truncover;
         length raw_line $32767;
         input raw_line $char32767.;
         
         if _n_ = 1 then put "--- START OF ENVIRONMENT VARIABLES ---";
         put raw_line;
      run;
      
      filename envcmd clear;
   %end;
   %else %if &mode. = DATASET or &mode. = BOTH %then %do;
      /* Read variables into a permanent or work dataset */
      filename envcmd pipe "&os_cmd." lrecl=32767;
      
      data &dsout.;
         infile envcmd truncover;
         length raw_line $32767 var_name $250 var_value $32517;
         input raw_line $char32767.;
         
         if index(raw_line, '=') > 0 then do;
            var_name  = substr(raw_line, 1, index(raw_line, '=') - 1);
            var_value = substr(raw_line, index(raw_line, '=') + 1);
            output;
         end;
         keep var_name var_value;
      run;
      
      filename envcmd clear;
      
      /* If BOTH is requested, write the processed table data to the log */
      %if &mode. = BOTH %then %do;
         data _null_;
            set &dsout.;
            put "SYSGET Name: " var_name / "Value      : " var_value / "-----------------------------------";
         run;
      %end;
   %end;
   %else %do;
      %put %str(ERR)OR: Invalid MODE specified. Please use BOTH, LOG, or DATASET.;
   %end;

%mend sysgetenvvars;
%* sysgetenvvars;
