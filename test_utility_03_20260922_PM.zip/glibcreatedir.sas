/*******************************************************************************
* Program Name: glibcreatedir.sas
* Program Type: Global Utility Macro
* Description : Load a macro array to create a list of folders.    
* Created By  : Wayne Saraphis
* Created     : August 26, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  path         - Macro variable with path.
*  total        - Macro variable with total files.
*  var          - Macro variable with file names. 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 26, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro glibcreatedir(
   path=,
   total=,
   var=
 )
;

   options dlcreatedir;

   %do jj = 1 %to &total.;
      libname _temp_ "&path.&&var&jj..";
   %end;

%mend glibcreatedir;
