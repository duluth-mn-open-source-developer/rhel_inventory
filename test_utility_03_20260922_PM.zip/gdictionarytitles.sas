/*******************************************************************************
* Program Name: gdictionarytitles.sas
* Program Type: Global Utility Macro
* Description : Get a list of current set titles.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsout        - (Optional) Output dataset. 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdictionarytitles(
  dsout=
 )/des="Global: Utility macro to get titles and footnotes."
;
    proc sql noprint;	
	   create table &dsout. as 
	   select * 
	   from dictionary.titles;
	quit;
%mend gdictionarytitles;

