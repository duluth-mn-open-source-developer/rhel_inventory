/*******************************************************************************
* Program Name: gprocreport.sas
* Program Type: Global Utility Macro
* Description : Generic PROC REPORT macro.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  data                   - Driver dataset
*  meta                   - Control dataset
*  odsdest                - ODS Destination
*  outfile                - Outfile 
*  title                  - Title 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocreport
 (
    data=,
    meta=,
    odsdest=PDF,
    outfile=C:\Temp\report_output, 
    title=          
 )/des="Global: Utility macro for PROC REPORT."
;

    /* --- Step A: Extract column list and individual DEFINE statement rows --- */
    proc sql noprint;
        select ColName into :col_list separated by ' '
        from &meta;
    quit;

    /* Use a data step to write each DEFINE statement into an indexed macro variable */
    data _null_;
        set &meta nobs=n;
        length line $500;
       
        /* Construct the individual define line */
        line = catx(' ', 'define', strip(ColName), '/', strip(Usage));
        if width ne . then line = catx(' ', line, 'width=' || strip(put(width,best.)));
        if format ne ' ' then line = catx(' ', line, 'format=' || strip(Format));
        if ColLabel ne ' ' then line = catx(' ', line, 'label="' || strip(ColLabel) || '"');
        line = catx(' ', line, ';');
       
        /* Create numbered macro variables: &def1, &def2, &def3, etc. */
        call symputx(cats('def', _n_), line);
       
        /* Store the total count for the macro loop later */
        if _n_ = 1 then call symputx('num_defs', n);
    run;

    /* --- Step B: Open ODS Destination dynamically (PDF, HTML, or RTF) --- */
    %if %upcase(&dest) = PDF %then %do;
        ods pdf file="&outfile..pdf" style=journal;
    %end;
    %else %if %upcase(&dest) = HTML %then %do;
        ods html file="&outfile..html" style=styles.HTMLBlue;
    %end;
    %else %if %upcase(&dest) = RTF %then %do;
        ods rtf file="&outfile..rtf" style=journal;
    %end;

    %if &title ne %str() %then %do;
        title1 "&title";
    %end;

    /* --- Step C: Execute PROC REPORT --- */
    proc report data=&data nowd headline headskip split='*';
       
        /* Inject the column list */
        column &col_list;

        /* Loop through and write out individual DEFINE statements cleanly */
        %do i = 1 %to &num_defs;
            &&def&i;
        %end;

        rbreak after / summarize;
    run;

    /* --- Step D: Close ODS Destination --- */
    ods _all_ close;
    title;
    
%mend gprocreport;
