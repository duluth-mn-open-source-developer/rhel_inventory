/*******************************************************************************
* Program Name: gsetup.sas
* Program Type: Global Utility Macro
* Description : Setup for SAS execution.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gsetup/des="Global: Utility macro to setup program execution.";
   filename _temp_ "..";
   options append=sasautos=(_temp_);
   %put %sysfunc(getoption(sasautos));
   %goptions;
   title;
   footnote;
   filename _temp_ clear;
%mend gsetup;
%* gsetup;
