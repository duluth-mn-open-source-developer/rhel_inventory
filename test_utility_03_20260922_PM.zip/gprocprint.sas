/*******************************************************************************
* Program Name: gprocprint.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC PRINT.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  data              - Output dataset  
*  obs               - Number of observations
*  label             - Apply labels (YES)
*  where             - Filter for data set
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocprint(
    data=,
    obs=50,
    label=YES,
    where=
 )/des="Global: Utility macro to set options for PROC PRINT."
;
    %if %length(&data.) = 0 %then %do;
        %put ERROR: [gprint] Input dataset (data=) must be specified.;
        %return;
    %end;

    proc print data=&data.
        %if &obs. > 0 %then (obs=&obs.);
        %if %upcase(&label.) = YES %then label;;
        ;
        %if %length(&where.) > 0 %then where (&where.);
    run;
    
%mend gprocprint;