/*******************************************************************************
* Program Name: gdirlist.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for getting a list of directories 
* Created By  : Wayne Saraphis
* Created     : September 17, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  pathin       - (Mandatory) Root directory for directory list.
*  dsout        - (Mandatory) Output dataset.                        
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 17, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdirlist(pathin=,dsout=)/des="Global: Get list of directories";

   * 1. Create a temporary dataset to hold the results ;
   data &dsout.(keep=directory_path);
      length directory_path $1024;
        
      * 2. Open the root directory ;
      rc_dir = filename("root", "&pathin.");
      if rc_dir = 0 then do;
         dir_id = dopen("root");
            
         if dir_id > 0 then do;
            * 3. Loop through all items inside the folder ;
            num_items = dnum(dir_id);
            do i = 1 to num_items;
               item_name = dread(dir_id, i);
                    
               * 4. Construct the full path of the item ;
               * Uses standard backslash for Windows paths ;
               if substr("&pathin.", length("&pathin.")) = "\" then 
                  full_path = trim("&pathin.") || trim(item_name);
                  else 
                     full_path = trim("&pathin.") || "\" || trim(item_name);
                    
                     * 5. Check if the item is a directory or a file ;
                     rc_chk = filename("chk", full_path);
                     chk_id = dopen("chk");
                    
                     * If it opens successfully as a directory, save it ;
                     if chk_id > 0 then do;
                        directory_path = tranwrd(full_path,'/','\');
                        put directory_path;
                        output;
                        rc_cls = dclose(chk_id);
                     end;
                     rc_chk = filename("chk", "");
            end;
            rc_dir = dclose(dir_id);
         end;
      end;
      rc_dir = filename("root", "");
   run;
    
%mend gdirlist;

