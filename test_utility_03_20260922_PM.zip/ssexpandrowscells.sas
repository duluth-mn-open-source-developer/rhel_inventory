/*******************************************************************************
* Program Name: ssexpandrowscells.sas
* Program Type: Smartsheet Utility Macro
* Purpose     : Join columns and rows_cells to get a SAS data set for transpose.
* Created By  : Wayne Saraphis
* Created     : Sep 01, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsout        - Output dataset name 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 01, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssexpandrowscells(
  dsout=
 )/des="Smartsheet: Expand rows and cells with columns."
;
   proc sql noprint;
      create table &dsout. as 
      select
         c.id as rowid "Smartsheet Id",
         b.id   "Smartsheet Column Id",
         a.ordinal_rows,
         b._varnum "SAS Variable Number",
         b._name "SAS Variable Name",
         b._label "SAS Label",  
         b._informat "SAS Informat",
         b._format "SAS Format",  
         a.value
      from _out_.rows_cells as a
         left join columns as b
         on b.id=a.columnid
         left join _out_.rows as c
         on c.ordinal_rows=a.ordinal_rows
         where b.id ne .
      order by a.ordinal_rows, a.ordinal_cells;
   quit;
%mend ssexpandrowscells;
%* ssexpandrowscells(dsout=_out_.joined);
   
   

