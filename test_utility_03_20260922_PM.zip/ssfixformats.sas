/*******************************************************************************
* Program Name: ssfixformats.sas
* Program Type: Smartsheet Utility Macro
* Description : Fix formats for IDs and other Smartsheet to SAS imported tables.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  libin                  - Input libname from proc copy json to lib.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssfixformats(
  libin=
 )/des="Smartsheet: Format fields for SAS."
;

   proc sql noprint;
      select memname into:dsn separated by ' ' from dictionary.tables where libname = %upcase("&libin.");
   quit;
   
   %put NOTE: the macro variable dsn has the value &dsn.;

   %if %sysfunc(index(&dsn.,COLUMNS)) and %sysfunc(exist(&libin..COLUMNS)) %then %do;
      data &libin..columns;
         set &libin..columns;
         format id 20.;
      run;   
   %end;   
   %if %sysfunc(index(&dsn.,ROWS)) and %sysfunc(exist(&libin..ROWS)) %then %do;
      data &libin..rows(rename=(xcreatedat=createdat xmodifiedat=modifiedat));
         set &libin..rows;
         format id siblingid 20. xcreatedat xmodifiedat datetime20.;
         xcreatedat = input(createdat,anydtdtm.);
         xmodifiedat = input(modifiedat,anydtdtm.);
         drop createdat modifiedat;
      run;   
   %end;   
   %if %sysfunc(index(&dsn.,WORKSPACE)) and %sysfunc(exist(&libin..WORKSPACE)) %then %do;
      data &libin..workspace;
         set &libin..workspace;
         format id 20.;
      run;   
   %end;   
   %if %sysfunc(index(&dsn.,ROWS_CELLS)) and %sysfunc(exist(&libin..ROWS_CELLS)) %then %do;
      data &libin..rows_cells;
         set &libin..rows_cells;
         format columnid 20.;
      run;   
   %end;   
   %if %sysfunc(index(&dsn.,DATA)) and %sysfunc(exist(&libin..DATA)) %then %do;
      data &libin..data(rename=(xcreatedat=createdat xmodifiedat=modifiedat));
         set &libin..data;
         format id 20. xcreatedat xmodifiedat datetime20.;
         xcreatedat = input(createdat,anydtdtm.);
         xmodifiedat = input(modifiedat,anydtdtm.);
         drop createdat modifiedat;
      run;   
   %end;   
   %if %sysfunc(index(&dsn.,ROOT)) and %sysfunc(exist(&libin..ROOT)) %then %do;
      data &libin..root(rename=(xcreatedat=createdat xmodifiedat=modifiedat));
         set &libin..root;
         format id 20. xcreatedat xmodifiedat datetime20.;
         xcreatedat = input(createdat,anydtdtm.);
         xmodifiedat = input(modifiedat,anydtdtm.);
         drop createdat modifiedat;
      run;   
   %end;   

%mend ssfixformats;
%* ssfixformats;
