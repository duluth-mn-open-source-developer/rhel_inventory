/*******************************************************************************
* Program Name: ssfixformats.sas
* Program Type: Smartsheet Utility Macro
* Purpose     : Fix formats for IDs and other Smartsheet to SAS imported tables.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  libin                  - Input libname from proc copy json to lib.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ssfixformats(
  libin=_out_
 )/des="Smartsheet: Format fields for SAS."
;

   proc sql noprint;
      select memname into:dsn separated by ' '
      from dictionary.tables
      where libname = %upcase("&libin.");
   quit;
   
   %put NOTE: the macro variable dsn has the value &dsn.;

   proc datasets lib=&libin. nodetails nolist nowarn;
      %if %sysfunc(index(&dsn.,COLUMNS)) %then %do;
         modify columns;
         format id 20.;
      %end;   
      %if %sysfunc(index(&dsn.,ROWS)) %then %do;
         modify rows;
         format id 20. siblingid 20.;
      %end;   
      %if %sysfunc(index(&dsn.,WORKSPACE)) %then %do;
         modify workspace;
         format id 20.;
      %end;   
      %if %sysfunc(index(&dsn.,ROWS_CELLS)) %then %do;
         modify rows_cells;
         format columnid 20.;
      %end;   
      %if %sysfunc(index(&dsn.,DATA)) %then %do;
         modify data /correctencoding=utf8;
         format id 20.;
      %end;   
   run;

%mend ssfixformats;
%* ssfixformats;
