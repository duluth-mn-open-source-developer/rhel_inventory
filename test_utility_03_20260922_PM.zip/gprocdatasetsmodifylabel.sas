/*******************************************************************************
* Program Name: gprocdatasetsmodifylabels.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for adding a label to a dataset. 
* Created By  : Wayne Saraphis
* Created     : September 7, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  libref       - Dataset to add label.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 7, 2026   | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocdatasetsmodifylabels(
  libref=
 )/des="Global: Add a label to a dataset."
;

    data _null_;
       length count 3. string $512.;
       set sashelp.vmember(where=(lowcase(libname)=lowcase("&libref.")));
       count + 1;
       string = memname;
       call symputx(cat('string',count),trim(left(string)),'G');
       call symputx('totalstrings',count,'G');
       retain count 0;
    run; 
    
    %do ii =  1 %to &totalstrings.;
       %put NOTE: the global macro variable string&ii has the value &&string&ii;
    %end;

    proc datasets lib=&libref nolist;
       %do ii =  1 %to &totalstrings.;
          modify &&string&ii (label="&&string&ii") / correctencoding=utf8;
       %end;
    quit;

%mend gprocdatasetsmodifylabels;
%* gprocdatasetsmodifylabels(libref=_out_);
