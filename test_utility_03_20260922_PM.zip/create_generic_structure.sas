/*******************************************************************************
* Program Name: create_folder.sas
* Program Type: Global Utility Macro
* Purpose     : Create folders from dataset. 
* Created By  : Wayne Saraphis
* Created     : August 14, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  ds                - (Mandatory) Input SAS dataset.
*  var               - (Mandatory) Variable with value to put into the array.
*  prefix            - (Optional) Prefix for macro array.
                       Default: name
*  counter           - (Optional) Counter for macro array.
                       Default: total
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 14, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro create_folders(root_path=,type=dev,dsin=folder_list);

 %create_global_array_from_ds
  (
   ds         = &dsin.,
   var        = value,
   prefix     = folder,
   counter    = total
  )
 ;

 /* 1. Basic input validation */
 %if %sysevalf(%superq(root_path)=, boolean) %then %do;
  %put %str(ERR)OR: The root_path parameter cannot be blank.;
  %return;
 %end;

 option dlcreatedir;
 libname _temp_ "&root_path.";
 libname _temp_ clear;

 libname _temp_ "&root_path.\&type.";
 libname _temp_ clear;

 %do jj = 1 %to &total.;
  libname _temp_ "&root_path.\&type.&&folder&jj..";
  libname _temp_ clear;
 %end;

%mend create_folders;

/* 1. Build out the Development Sandbox */
%create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0000_folders);
%* create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0000_core);
%* create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0001_gsetup);
%* create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0002_folders);
%* create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0003_rtf_combine);
%* create_folders(root_path=D:/DM and Programming/DM/Utilities,type=_0004_pfd_combine);

/* 2. Build out the Testing and Quality Control Center */
%* create_generic_structure(root_path=D:\DM and Programming\DM\utilities\val);

/* 3. Build out the Production environment */
%* create_generic_structure(root_path=D:\DM and Programming\DM\utilities\prod);
