/*******************************************************************************
* Program Name: gdictionarylist.sas
* Program Type: Global Utility Macro
* Description : Get a list of all dictionary tables.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsout        - (Optional) Output dataset. 
*  mode         - (Mandatory) Output location LOG or SAS dataset.
                  Default:  BOTH (LOG and SAS dataset)
                  Optional: LOG 
                  Optional: DATASET
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdictionarylist
 (
  dsout=work.vdctnry,
  mode=BOTH
 )/des="Global: Utility macro to get a list of all dictionary tables."
;

   /* 1. Standardize input parameters to uppercase */
   %let mode = %upcase(&mode.);

   proc sql noprint;
      create table _temp_ as 
      select distinct memname 
      from sashelp.vdctnry;
   quit;
 
   %if &mode. = DATASET or &mode. = BOTH %then %do;
      data &dsout.;
         set _temp_;
      run;
   %end; 

   %if &mode. = LOG %then %do;
      data _null_;
         set _temp_;
         if _n_ = 1 then put "NOTE: List of Dictionary Tables:";
         put memname;
      run;
   %end; 
   
%mend gdictionarylist;
%gdictionarylist(mode=BOTH);
