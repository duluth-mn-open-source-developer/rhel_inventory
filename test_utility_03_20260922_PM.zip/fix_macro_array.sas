%macro GetFileList(dir=,libout=);

   %local target_dir;
    
   * Strip quotation marks if the user accidentally included them;
   %let target_dir = %sysfunc(dequote(&dir));

   option dlcreatedir;
   libname _out_ "&libout." outencoding="UTF-8";
   
   * Execute the Data Step to generate the file list;
   data _out_._temp_;
      length full_path $300 filename $300; 
        
      * Run Windows DIR command via PIPE;
      * /B = Bare format, /A:-D = Exclude directories;
      filename _mypipe pipe "dir ""&target_dir."" /B /A:-D 2>nul";
        
      infile _mypipe truncover;
      input filename $300.;
        
      * Combine folder path and filename with a backslash;
      file_name = catx('\', "&target_dir.", filename);
        
      keep file_name;
   run;
   
   data _null_;
      set _out_._temp_;
      call symputx(compress('name',_n_),file_name,'G');
      call symputx('totalnames',_n_,'G');
   run;   
   
   %do jj = 1 %to &totalnames.;
      %put NOTE: the global macro variable name&jj. has the value &name&&jj..;
   %end;

   * Clean up the filename reference;
   filename _mypipe clear;
    
%mend GetFileList;
%GetFileList(
  dir=D:\DM and Programming\DM\Utilities\01-folder-templates,
  libout=D:\DM and Programming\DM\Utilities\01-folder-templates\temp
 )
;
