/*******************************************************************************
* Program Name: gzip.sas
* Program Type: Global Utility Macro
* Description : Generic utility macros for creating zip       
*               archives using the SAS FILENAME ZIP access method. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  target_directory - Target directory to zip.
*  zip_path         - Zip file path out.
*  zip_name         - Zip file name.
*  file_filter      - File filter to add to zip. 
*  dsout            - Output dataset. 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gzip(
  target_directory=,
  zip_path=,
  zip_name=,
  file_filter=*.*,
  dsout=_temp_
 )/des="Global: Utility macro to create zip archives."
;

   * Execute the Data Step to generate the file list;
   data _temp_;
      length full_path $1024. filename $1024.; 
        
      * Run Windows DIR command via PIPE;
      * /B = Bare format, /A:-D = Exclude directories;
      filename _pipe pipe "dir ""&target_directory."" /B /A:-D 2>nul";
        
      infile _pipe truncover;
      input filename $1024.;
        
      * Combine folder path and filename with a backslash;
      full_path = tranwrd(catx('\', "&target_directory.", filename),'/','\');
        
      call symputx(cat('name',_n_),full_path,'G');
      call symputx('totalnames',_n_,'G');

   run;
   
   %do jj = 1 %to &totalnames.;
      %put NOTE: the global macro variable name&jj. has the value &&name&jj;
   %end;

   * Clean up the filename reference;
   filename _pipe clear;

   ods package(zip_package) open nopf;

   %do kk = 1 %to &totalnames.;
       ods package(zip_package) add file="&&name&kk";
   %end;

   ods package(zip_package) publish archive 
       properties(
           archive_path="&zip_path."
           archive_name="&zip_name." 
       );

   ods package(zip_package) close;

   libname _out_ clear;

%mend gzip;
%gzip
 (
    target_directory=D:/DM and Programming/DM/Utilities,
    zip_path=D:/DM and Programming/DM/Utilities/99-archive,
    zip_name=test_utility_20260921_1014_AM.zip,
    file_filter=*.*
  )
;
