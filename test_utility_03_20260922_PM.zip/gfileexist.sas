/*******************************************************************************
* Program Name: gfileexist.sas
* Program Type: Global Utility Macro
* Description : Set global macro variable for fileexist.
* Created By  : Wayne Saraphis
* Created     : August 17, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  pathin            - Input path.
*  mvar              - Returned value (rc)
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 17, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gfileexist(
 pathin=,
 mvar=rc
)/des="Global: Utility macro to set global macro variable for fileexist."
;
    %symdel &mvar. /nowarn;
    %global &mvar.;
    %let &mvar. = %sysfunc(fileexist(&pathin.));
    %if &&&mvar.=0 %then %do;
       %put ERROR: the path does not exist: &pathin.;
    %end;
    %if &&&mvar.=1 %then %do;
       %put NOTE: the path exists: &pathin.;
    %end;
    %put NOTE: the global macro variable &mvar. has the value &&&mvar. ;
%mend gfileexist;

/* --- Example Usage --- */
%* gfileexist(pathin=D:); 
%* gfileexist(pathin=C:/Users/waynesaraphis/Desktop); 
%* gfileexist(pathin=D:/DM and Programming/DM/Utilities/dev/01_development/compound_study_folders.sas);