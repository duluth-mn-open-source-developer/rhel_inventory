/*******************************************************************************
* Program Name: gprocsummaryfmtdsn.sas
* Program Type: Global Utility Macro
* Description : Generic global utility to create a class format from PROC SUMMARY.
* Created By  : Wayne Saraphis
* Created     : September 07, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin         - Summary dataset in
*  dsout        - Format data set out (fmtout)
*  fmtname      - Format name out ($temp)
*  type         - Format character or numeric (C)
*  label        - Format label (core)
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 07, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocsummaryfmtdsn(
  dsin=,
  dsout=fmtout,
  fmtname=$temp,
  type=C,
  label=core
 )/des="Global: Create a class format from PROC SUMMARY"
;
   data &dsout.;
      set &dsin.
       (
        rename=(
         name=START 
         label=LABEL
         )
        );
    
      * Define the format name you want to create;
      fmtname = "&fmtname."; 
    
      * Optional: Ensure TYPE matches your variable (C for character, N for numeric);
      type = "&type."; 
    
      keep START LABEL FMTNAME TYPE;
   run;

%memd gprocsummaryfmtdsn;
%* gprocsummaryfmtdsn;

