/*******************************************************************************
* Program Name: gdsvalid.sas
* Program Type: Global Utility Macro
* Description : Setup for SAS execution.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin              - (Mandatory) Input SAS dataset.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gdsvalid(
 dsin=
)/des="Global: Setup for SAS execution."
;
    /* Check if the dataset exists in the libraries */
    %if %sysfunc(exist(&dsin.)) %then %do;
        
        /* Open dataset to check the observation count */
        %local dsid nobsrc;
        %let dsid = %sysfunc(open(&dsin.));
        %let nobsrc = %sysfunc(attrn(&dsid., nobs));
        %let dsid = %sysfunc(close(&dsid.));
        
        %if &nobsrc. = 0 %then %do;
            %put %str(ERR)OR: Dataset &ds_name. is empty. Reporting aborted.;
            %abort cancel;
        %end;
        %else %do;
            %put NOTE: Dataset &ds_name. validated successfully with &nobsrc. rows.;
        %end;
    %end;
    %else %do;
        %put %str(ERR)OR: Dataset &dsin. does not exist. Reporting aborted.;
        %abort cancel;
    %end;
%mend gdsvalid;
