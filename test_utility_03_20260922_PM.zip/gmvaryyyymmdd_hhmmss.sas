/*******************************************************************************
* Program Name: gmvaryyyymmdd_hhmmss.sas
* Program Type: Global Utility Macro
* Description : Set global macro variable for datetime.
* Created By  : Wayne Saraphis
* Created     : August 30, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  mvar        - Global macro variable containing yyyymmdd_hhmmss value.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 30, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gmvaryyyymmdd_hhmmss(
  mvar=gyyyymmdd_hhmmss
 )/des="Global: Macro variable for datetime (yyyymmdd_hhmmss)"
;

   %global &mvar.;
   
   proc format; 
      picture yymmddhms low-high = '%Y%0m%0d_%0H%0M%0S' (datatype=datetime); 
   run;
   
   %let &mvar.=%sysfunc(putn(%sysfunc(datetime()),yymmddhms.));
   
   %put NOTE: the global macro variable &mvar. has the value &&&mvar..;
   
%mend gmvaryyyymmdd_hhmmss;
%* gmvaryyyymmdd_hhmmss(mvar=gyyyymmdd_hhmmss);
   