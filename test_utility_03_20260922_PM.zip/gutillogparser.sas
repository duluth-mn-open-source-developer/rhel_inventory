/*******************************************************************************
* Program Name: gutillogparser.sas
* Program Type: Global Utility Macro
* Description : Generic utility macro for parsing execution logs to scan  
*               for critical keywords like ERROR, WARNING, or FATAL. 
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  log_file_path        - Log file location.
*  output_error_dataset - Output ERROR dataset.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gutillogparser
 (
    log_file_path=,
    output_error_dataset=work.log_exceptions_summary
 )/des="Global: Utility macro to for parsing execution logs."
;

    %if %sysfunc(fileexist(&log_file_path.)) = 0 %then %do;
        %put ERROR: Log file path does not exist: &log_file_path.;
        %return;
    %end;

    %put NOTE: Parsing log file: &log_file_path.;

    filename saslog "&log_file_path.";

    data &output_error_dataset. (keep=line_number log_line issue_type);
        length log_line $500 issue_type $20;
        infile saslog truncover;
        input log_line $500.;
        line_number + 1;
        
        up_line = upcase(log_line);
        if index(up_line, "ERROR:") > 0 then issue_type = "ERROR";
        else if index(up_line, "WARNING:") > 0 then issue_type = "WARNING";
        else if index(up_line, "FATAL:") > 0 then issue_type = "FATAL";
        else delete;
    run;

    filename saslog clear;

    %put NOTE: Log parsing complete. Exceptions saved to: &output_error_dataset.;

%mend gutillogparser;