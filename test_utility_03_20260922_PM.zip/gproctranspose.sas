/*******************************************************************************
* Program Name: gtranspose.sas
* Program Type: Global Utility Macro
* Description : Transpose a dataset.
* Created By  : Wayne Saraphis
* Created     : Sep 01, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  dsin         - Input long dataset name 
*  dsout        - Desired output wide dataset name 
*  byvar        - Column to group on (ordinal_rows) 
*  idvar        - Column containing future header names (_name_) 
*  labelvar     - Column containing future descriptions (_label_) 
*  valuevar     - Column holding the data points (value) 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 01, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gproctranspose(
   dsin=,       /* Input long dataset name */
   dsout=,      /* Desired output wide dataset name */
   byvar=,      /* Column to group on (ordinal_rows) */
   idvar=,      /* Column containing future header names (_name_) */
   labelvar=,   /* Column containing future descriptions (_label_) */
   valuevar=    /* Column holding the data points (value) */
 )/des="Global: Transpose a dataset"
;

    /* 1. Ensure input data is structurally ordered for the BY group */
    proc sort data=&dsin. out=_temp;
        by &byvar.;
    run;

    /* 2. Execute the transpose mapping headers and labels */
    proc transpose data=_temp 
                   out=&dsout.(drop=_name_);
        by &byvar.;
        id &idvar.;
        idlabel &labelvar.;
        var &valuevar.;
    run;

    /* 3. Housekeeping: Remove intermediate sorted dataset */
    proc datasets lib=work nodetails nolist nowarn;
       * delete _temp;
    run;

%mend gproctranspose;
* Test case is the joined columns and rows_cells dataset;
%* gproctranspose(
    dsin=_out_.joined,
    dsout=_out_.joinedwide,
    byvar=ordinal_rows,
    idvar=_name,
    labelvar=_label,
    valuevar=value
);
