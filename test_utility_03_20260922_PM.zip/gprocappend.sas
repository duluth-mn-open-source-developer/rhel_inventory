/*******************************************************************************
* Program Name: gprocappend.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC APPEND.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  base              - Base data   
*  new               - Append data  
*  force             - Force concatenation (NO) 
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocappend(
  base=, 
  new=, 
  force=NO
 )/des="Global: Utility macro for PROC APPEND."
;
    %local m_err;
    %let m_err = 0;

    %if %length(&base.) = 0 or %length(&new.) = 0 %then %do;
        %put ERROR: [utl_append] Both base= and new= datasets must be specified.;
        %let m_err = 1;
    %end;

    %if &m_err. = 1 %then %goto exit;

    proc append base=&base. data=&new.
        %if %upcase(&force.) = YES %then force;;
    run;

    %put NOTE: [gappend] Appended &new. into &base.;

%exit:
%mend gprocappend;
