%macro gchkdups(dsin=,dsout=,primary_key=,secondary_keys=);

   proc sort data=&dsin. out=_temp_; by &primary_key. &secondary_keys.; run;
   
   data &dsout.(keep=&primary_key. &secondary_keys. count);
      set _temp_;
      by &primary_key. &secondary_keys.;
      length count 3.;
      if first.&primary_key. then count=0;
      count+1;
      retain count 0;
   run;   
   
%mend gchkdups;
