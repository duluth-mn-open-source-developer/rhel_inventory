/* 1. Establish the unnamed pipe to run the command */
filename syspipe pipe "systeminfo" lrecl=32767;

/* 2. Read the pipe output directly into a SAS dataset */
data work.system_configuration;
    infile syspipe truncover;
    input raw_line $char200.;
    
    /* Clean up the string padding */
    raw_line = strip(raw_line);
    
    /* Parse out only the rows we care about */
    if prxmatch('/^(OS Name|OS Version|System Type|Total Physical Memory):/i', raw_line) then do;
        Metric = strip(scan(raw_line, 1, ":"));
        Value  = strip(scan(raw_line, 2, ":"));
        put metric '~' value;
        output;
    end;
    
    keep Metric Value;
run;

/* 3. View the collected metrics */
proc print data=work.system_configuration noobs;
    title "Windows System Info Captured via SAS Pipe";
run;
title;

/* 4. Clear the fileref assignment */
filename syspipe clear;