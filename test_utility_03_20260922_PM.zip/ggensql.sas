/*******************************************************************************
* Program Name: ggensql.sas
* Program Type: Global Utility Macro
* Description : Generic global utility to write SQL from a dataset.
* Created By  : Wayne Saraphis
* Created     : September 9, 2026
*
* Clinical Context:
*               Designed for validated clinical dsin pipeline architectures
*               requiring secure communication with external Electronic dsin
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log dsoutput and controlled error
*               handling withdsout breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  libin       - Input library.
*  dsin        - Input dataset.
*  libout      - Output library.
*  dsout       - Output dataset.
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Sep 9, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro ggensql(libin=,dsin=,libout=WORK,dsout=NEW_TABLE);

   /* Convert library and dataset names to uppercase for dictionary tables */
   %let libin    = %lowcase(&libin.);
   %let dsin     = %lowcase(&dsin.);
   %let libout   = %lowcase(&libout.);
   %let dsout    = %lowcase(&dsout.);

   /* Fetch column metadata into a temporary table */
   proc sql noprint;
      create table _column_metadata_ as
      select
         varnum,
         name,
         type,
         length,
         format,
         label
      from dictionary.columns
         where lowcase(libname) = "&libin." and lowcase(memname) = "&dsin."
            order by varnum;
   quit;

   /* Generate and print the SQL statement */
   data _null_;
      length col_def $128.;
      set _column_metadata_ end=eof;
      if _n_ = 1 then do;
         put @4 "proc sql noprint;";
         put @7 "create table &libout..&dsout. as";
         put @7 "select";
      end;
      /* Format individual column definitions */
      col_def = name;
      if length ne . then col_def = strip(col_def) || " length=" || strip(length);
      if format ne ' ' then col_def = cats(col_def," format=", format);
      if label ne ' ' then col_def = cats(col_def,' label="', trim(label), '"');
      if _n_ > 1 then col_def = cats(col_def, ",");
      put @10 col_def;
      if eof then do;
         put @7 "from &libout..&dsout.;";
         put @4 "quit;";
      end;
   run;
   
%mend ggensql;
/* Example Usage: */
%* ggensql(lib=SASHELP, mem=CLASS, outlib=WORK, outtable=CLASS_COPY); */