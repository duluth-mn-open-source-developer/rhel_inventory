/*******************************************************************************
* Program Name: gproccompare.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC COMPARE with support
*               for baseline vs. comparison datasets and metadata output.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  base              - Base data
*  compare           - Compare data
*  out               - Output dataset
*  id                - ID variable 
*  criterion         - Comparison criteria 
*  method            - Comparison method
*  noprint           - Print (NO)
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gproccompare(
    base=,
    compare=,
    out=,
    id=,
    criterion=,
    method=,
    noprint=NO
 )/des="Global: Utility macro for PROC COMPARE."
;
    %local m_err;
    %let m_err = 0;

    /* Parameter validation */
    %if %length(&base.) = 0 or %length(&compare.) = 0 %then %do;
        %put ERROR: [gcompare] Both base= and compare= datasets must be specified.;
        %let m_err = 1;
    %end;

    %if &m_err. = 1 %then %goto exit;

    /* Execution */
    proc compare base=&base. compare=&compare.
        %if %length(&out.) > 0 %then out=&out. outnoequal outbase outcomp;;
        %if %length(&criterion.) > 0 %then criterion=&criterion.;
        %if %length(&method.) > 0 %then method=&method.;
        %if %upcase(&noprint.) = YES %then noprint;;
        ;
        %if %length(&id.) > 0 %then id &id.;;
    run;

    %put NOTE: [gcompare] Comparison completed between &base. and &compare.;

%exit:
%mend gproccompare;
