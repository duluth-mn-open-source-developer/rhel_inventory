/*******************************************************************************
* Program Name: gprocfreq.sas
* Program Type: Global Utility Macro
* Description : Generic global utility macro for PROC FREQ.
* Created By  : Wayne Saraphis
* Created     : August 24, 2026
*
* Clinical Context:
*               Designed for validated clinical data pipeline architectures
*               requiring secure communication with external Electronic Data
*               Capture (EDC), clinical trial management systems (CTMS),
*               or regulatory submission repositories. Ensures complete
*               traceability via standardized log output and controlled error
*               handling without breaching 21 CFR Part 11 operational boundaries.
*
* Parameters:
*  data         - Input SAS dataset     
*  tables       - Table statement 
*  out          - Output dataset
*  noprint      - Print to listing output (NO)
*
* Change Control:
* Version | Modified Date | Modified By    | Description
* -----------------------------------------------------------------------------
* 0.1     | Aug 24, 2026  | Wayne Saraphis | Create program.
*******************************************************************************/
%macro gprocfreq(
    data=,
    tables=,
    out=,
    noprint=NO
 )/des="Global: Utility macro for PROC FREQ." 
;
    %local m_err;
    %let m_err = 0;

    %if %length(&data.) = 0 or %length(&tables.) = 0 %then %do;
        %put ERROR: [utl_freq] Both data= and tables= must be specified.;
        %let m_err = 1;
    %end;

    %if &m_err. = 1 %then %goto exit;

    proc freq data=&data.
        %if %upcase(&noprint.) = YES %then noprint;;
        ;
        tables &tables.
        %if %length(&out.) > 0 %then / out=&out. outcum;;
        ;
    run;

    %put NOTE: [gfreq] Frequencies processed for &data.;

%exit:
%mend gprocfreq;

